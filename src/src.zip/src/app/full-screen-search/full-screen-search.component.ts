import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-screen-search',
  templateUrl: './full-screen-search.component.html',
  styleUrls: ['./full-screen-search.component.css']
})
export class FullScreenSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
