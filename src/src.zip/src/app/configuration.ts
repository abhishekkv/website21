export const configuration = {
  header: {
    heading_1: "It services",
    heading_2: " Proactive solutions for smooth business operation",
  },
};
