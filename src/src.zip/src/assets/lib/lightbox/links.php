<?php
  $links = array(
    'css' => 'assets/lib/lightbox/css/lightbox.min.css',
    'js' => 'assets/lib/lightbox/js/lightbox.min.js'
  );
?>
