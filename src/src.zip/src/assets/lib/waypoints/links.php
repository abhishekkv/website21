<?php
  $links = array(
    'js' => 'assets/lib/waypoints/waypoints.min.js'
  );
?>
